import "./App.css";
import { useState } from "react";

function App() {
	const [position] = useState([1, 2, 3, 4, 5, 6, 7, 8, 9]);
	const [indicate, setIndicate] = useState(null);

	const handlePosition = (index) => {
		setIndicate(index);
		switch (index) {
			case 0:
				alert("Top Left");
				break;
			case 1:
				alert("Top Center");
				break;
			case 2:
				alert("Top Right");
				break;
			case 3:
				alert("Left Center");
				break;
			case 4:
				alert("Center");
				break;
			case 5:
				alert("Right Center");
				break;
			case 6:
				alert("Bottom Left");
				break;
			case 7:
				alert("Bottom Center");
				break;
			case 8:
				alert("Bottom Right");
		}
	};

	return (
		<div className="App">
			<header className="App-header">
				{position.map((item, index) => (
					<div
						className={`position_widget ${index === indicate && "bg"}`}
						key={index}
						onClick={() => handlePosition(index)}>
						{index === indicate ? <div className="indicator"></div> : null}
					</div>
				))}
			</header>
		</div>
	);
}

export default App;
